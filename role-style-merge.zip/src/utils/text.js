/**
 * src/utils/text.js
 * 📝 TEXT & PROSE PROCESSING ENGINE
 *
 * Core Responsibilities:
 * - Pure, stateless string manipulation, parsing, and formatting utilities.
 * - Cognition Stripping (`strip_cognition_blocks`): Strips `<think>...</think>` internal monologue blocks
 *   and model artifacts from AI responses before display, history persistence, or image generation.
 * - Pseudo-JSON & State Extraction (`safe_parse_pseudo_json`): Extracts bracketed `[KEY: VALUE]` parameters,
 *   enforcing universal atomic clearing (`CLEAR_TOKENS`), multi-item aggregation (`AGGREGATE_KEYS`), and raw prose fallback.
 * - Present State Field Mutation (`merge_prose_into_field`): Merges new bracket directives and state prose into
 *   physical/non-physical character fields.
 * - Relational Vector Serialization (`parse_relational_vector`, `format_relational_vector`): Manages directed graph edge syntax.
 * - Story Transcript & History Utilities: History collapsing, story title decomposition with entity colors,
 *   Swedish datetime formatting, and JSON quote escaping.
 *
 * Consumed across the engine by UI, State, Media, and Intelligence layers.
 */

import { CLOTHING_KEYS, escape_xml, prompt_escape } from "./xml.js";
import { CHARS_PER_TOKEN, CANONICAL_ROLES } from "@config";

// ============================================================================
// [SECTION 1: CONSTANTS & TOKEN SETS]
// ============================================================================

/**
 * Universal atomic-clearing tokens — emitting `[KEY: one of these]` deletes KEY
 * from the present-state dictionary (e.g. `[HELD: none]`, `[INJURY: healed]`,
 * `[STATUS: normal]`, `[SECRET: cleared]`).
 * @type {ReadonlySet<string>}
 */
export const CLEAR_TOKENS = Object.freeze(new Set(["none", "bare", "naked", "off", "removed", "disrobed", "healed", "cleared", "normal"]));

/**
 * Keys whose repeated brackets aggregate into a single multi-item array.
 * @type {ReadonlySet<string>}
 */
export const AGGREGATE_KEYS = Object.freeze(new Set(["INVENTORY", "STASH"]));

/**
 * Keys that must NEVER reach an image-generation prompt (private state or physical inventory).
 * @type {ReadonlySet<string>}
 */
export const VISUAL_EXCLUDED_KEYS = Object.freeze(new Set(["INVENTORY", "STASH", "SECRET", "PLAN", "STATUS"]));

/**
 * Matches an uppercase pseudo-JSON key (single or multi-word) terminated by a colon.
 */
const PSEUDO_JSON_KEY_REGEX = /\b([A-Z][A-Z0-9_]*(?:\s+[A-Z][A-Z0-9_]*)*)\s*:/g;

/**
 * Splits a bracket body into its constituent `KEY: value` segments, so a value
 * that swallowed a following key (e.g. `[HAIR: … temples DENTAL_FEATURES: …]`)
 * never merges keys or loses a key's opening bracket.
 * @param {string} content - Inner text of a `[...]` block.
 * @returns {{ key: string, value: string }[]}
 */
function _split_key_value_segments(content) {
  const text = String(content || "").trim();
  const lead = text.match(/^([^:[\]]+?)\s*:\s*/);
  if (!lead) return [];
  const segments = [{ key: lead[1], value: "" }];
  const rest = text.slice(lead[0].length);
  PSEUDO_JSON_KEY_REGEX.lastIndex = 0;
  const marks = [];
  let match;
  while ((match = PSEUDO_JSON_KEY_REGEX.exec(rest)) !== null) {
    if (rest.slice(PSEUDO_JSON_KEY_REGEX.lastIndex, PSEUDO_JSON_KEY_REGEX.lastIndex + 2) === "//") continue;
    marks.push({ key: match[1], start: match.index, value_start: PSEUDO_JSON_KEY_REGEX.lastIndex });
  }
  segments[0].value = (marks.length ? rest.slice(0, marks[0].start) : rest).trim();
  for (let i = 0; i < marks.length; i++) {
    const end = i + 1 < marks.length ? marks[i + 1].start : rest.length;
    segments.push({ key: marks[i].key, value: rest.slice(marks[i].value_start, end).trim() });
  }
  return segments;
}

/**
 * Stores a parsed pseudo-JSON entry, applying universal atomic clearing
 * (`CLEAR_TOKENS`) and multi-item aggregation (`AGGREGATE_KEYS`).
 * @param {Record<string, string | string[]>} target
 * @param {string} k
 * @param {string} v
 */
function _store_parsed_entry(target, k, v) {
  if (!k || !v) return;
  if (CLEAR_TOKENS.has(v.toLowerCase())) {
    delete target[k];
    return;
  }
  if (AGGREGATE_KEYS.has(k) || k.startsWith("@")) {
    const items = AGGREGATE_KEYS.has(k)
      ? v
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
      : [v];
    const existing = target[k];
    const list = Array.isArray(existing) ? existing : existing ? [existing] : [];
    for (const item of items) {
      if (item && !list.includes(item)) list.push(item);
    }
    target[k] = list;
    return;
  }
  target[k] = v;
}

/**
 * Model artifact leading prefixes to strip from prose output.
 */
const MODEL_ARTIFACT_PATTERNS = [/^Mattis\b(?:\.\s*Archetypes:[^\n]*\n*|\.|:|\s)*/i];

/**
 * Common title prefixes and stop words for entity naming and initials calculation.
 * @type {ReadonlyArray<string>}
 */
export const NAME_PREFIXES = Object.freeze([
  "mr",
  "mrs",
  "ms",
  "dr",
  "prof",
  "sir",
  "lady",
  "lord",
  "the",
  "a",
  "an",
  "of",
  "in",
  "and",
  "or",
  "for",
  "to",
  "at",
  "by",
  "with",
  "mr.",
  "mrs.",
  "ms.",
  "dr.",
  "prof.",
]);

/**
 * `NAME_PREFIXES` with trailing periods stripped, so a name token like "Dr."
 * matches its stop-word stem "dr". Shared by `compute_initials`.
 * @type {ReadonlySet<string>}
 */
export const NAME_PREFIX_STEMS = Object.freeze(new Set(NAME_PREFIXES.map((prefix) => prefix.replace(/\.$/, ""))));

/**
 * @typedef {Object} ParsedRelationalVector
 * @property {string} source_name - Source node entity name.
 * @property {string} target_name - Target node entity name.
 * @property {string} dynamic - Relationship bond or tension dynamic.
 * @property {string} raw - Original unparsed string.
 */

/**
 * @typedef {Object} StoryTitlePart
 * @property {string} text - Text slice.
 * @property {string} [color] - Entity signature color code.
 */

/**
 * @typedef {Object} HistoryMessage
 * @property {string} [role] - Message turn role.
 * @property {string} [content] - Message primary content.
 * @property {string} [text] - Fallback text content.
 * @property {string} [character_name] - Name of speaking character.
 */

/**
 * @typedef {Object} CollapsedHistoryEntry
 * @property {string} role - Standardized role ("user_persona" | "fractal" | "ai_character").
 * @property {string} name - Entity display name.
 * @property {string} content - Collapsed message content.
 */

// ============================================================================
// [SECTION 2: COGNITION & SANITIZATION UTILITIES]
// ============================================================================

/**
 * Strips cognition blocks (`<thinking>...</thinking>`), leaked <DYNAMICS> state blocks,
 * and model artifacts from prose.
 * @param {string | null | undefined} text - Input text.
 * @returns {string} Cleaned prose without internal thoughts.
 */
export function strip_cognition_blocks(text) {
  if (!text) return "";
  let clean = text.replace(/<think\b[^>]*>[\s\S]*?(?:<\/think\s*>|$)\r?\n?/gi, "");
  clean = clean.replace(/<\/think\s*>/gi, "");
  clean = clean.replace(/<DYNAMICS\b[^>]*>[\s\S]*?(?:<\/DYNAMICS\s*>|$)\r?\n?/gi, "");
  clean = clean.replace(/<\/?DYNAMICS\s*>/gi, "");
  for (const pattern of MODEL_ARTIFACT_PATTERNS) {
    clean = clean.replace(pattern, "");
  }
  return clean.trim();
}

/**
 * Extracts the outermost JSON object from a raw string.
 * Strips markdown code fences and isolates the substring between the first "{" and last "}".
 * @param {string | null | undefined} raw
 * @returns {string | null} Extracted JSON string, or null if no braces found.
 */
export function extract_json_block(raw) {
  if (!raw || typeof raw !== "string") return null;
  const stripped = raw.replace(/```json\n?|```/g, "").trim();
  const first_brace = stripped.indexOf("{");
  const last_brace = stripped.lastIndexOf("}");
  if (first_brace === -1 || last_brace === -1) return null;
  return stripped.substring(first_brace, last_brace + 1);
}

/**
 * Collapses every run of whitespace to a single space and trims the result.
 * @param {string | null | undefined} text
 * @returns {string}
 */
export function collapse_whitespace(text) {
  if (!text || typeof text !== "string") return "";
  return text.replace(/\s+/g, " ").trim();
}

/**
 * The single word-boundary truncator every layer shares — `clean_text`,
 * `derive_vector_title` (this module) and `truncate_readable` (html.js) all
 * delegate here, so clipping behaviour is defined once.
 *
 * @param {string | null | undefined} text
 * @param {number} [limit=200] - Character budget for the retained content.
 * @param {Object} [options={}]
 * @param {string} [options.ellipsis="…"] - Suffix appended only when text was cut.
 * @param {boolean} [options.reserve_ellipsis=false] - Count the ellipsis inside `limit`.
 * @param {number} [options.min_bound_ratio=0] - Only break at a space past this fraction of the budget.
 * @param {number} [options.min_bound_chars=0] - Only break at a space at/after this column.
 * @param {boolean} [options.strip_trailing_punctuation=false] - Drop trailing `. , ; :` before the ellipsis.
 * @returns {string}
 */
export function truncate_at_word(text, limit = 200, options = {}) {
  if (!text || typeof text !== "string") return "";
  const { ellipsis = "…", reserve_ellipsis = false, min_bound_ratio = 0, min_bound_chars = 0, strip_trailing_punctuation = false } = options;

  const trimmed = text.trim();
  if (trimmed.length <= limit) {
    return strip_trailing_punctuation ? trimmed.replace(/[.,;:]+$/, "") : trimmed;
  }

  const budget = reserve_ellipsis ? Math.max(1, limit - ellipsis.length) : limit;
  const sub = trimmed.slice(0, budget);
  const last_space = sub.lastIndexOf(" ");
  const threshold = Math.max(min_bound_chars, Math.floor(budget * min_bound_ratio));
  const cut = (last_space > threshold ? sub.slice(0, last_space) : sub).trimEnd();
  const final = strip_trailing_punctuation ? cut.replace(/[.,;:]+$/, "") : cut;
  return `${final}${ellipsis}`;
}

/**
 * Universal text truncation ensuring pseudo-JSON bracket syntax integrity.
 * If text contains pseudo-JSON brackets and a bracket tag is cut off mid-tag,
 * clips cleanly at the last intact ']' before limit; otherwise falls back to truncate_at_word.
 *
 * @param {string | null | undefined} text
 * @param {number} [limit=200]
 * @param {Object} [options={}]
 * @returns {string}
 */
export function truncate_at_boundary(text, limit = 200, options = {}) {
  if (!text || typeof text !== "string") return "";
  const trimmed = text.trim();
  if (trimmed.length <= limit) return trimmed;

  const sub = trimmed.slice(0, limit);
  const last_open = sub.lastIndexOf("[");
  const last_close = sub.lastIndexOf("]");

  // If there is an unclosed bracket cut off mid-tag
  if (last_open > last_close) {
    if (last_close > 0) {
      return sub.slice(0, last_close + 1).trimEnd();
    }
    // If the unclosed bracket is the very first one, drop it and return empty/trimmed
    return "";
  }

  return truncate_at_word(text, limit, options);
}

/**
 * Heuristic token estimator for prompt budgeting (Track 2.2: 6k cliff guard).
 * Inference servers bill and truncate on tokens; prose averages ~3.35 characters
 * per token in BPE tokenizers when structured prompt XML and pseudo-JSON brackets are present.
 * @param {string} text
 * @returns {number} Estimated token count (0 for blank input).
 */
export function estimate_tokens(text) {
  const length = String(text ?? "").length;
  if (length === 0) return 0;
  return Math.max(1, Math.ceil(length / CHARS_PER_TOKEN));
}

/**
 * Text sanitization for prompt safety.
 * Removes markdown-like characters and collapses redundant whitespace.
 * @param {string | null | undefined} text
 * @param {number} [limit=500] - Maximum character boundary.
 * @returns {string} Sanitized string.
 */
export function clean_text(text, limit = 500) {
  if (!text || typeof text !== "string") return "";
  const clean = collapse_whitespace(text.replace(/[*_~`#[\]]/g, " "));
  if (limit && clean.length > limit) {
    return truncate_at_word(clean, limit, { ellipsis: "..." });
  }
  return clean;
}

/**
 * Replaces unescaped interior double-quotes with backslashed equivalents (\") inside JSON string values.
 * @param {string} json_string
 * @returns {string}
 */
export function escape_unescaped_json_quotes(json_string) {
  if (typeof json_string !== "string") return json_string;
  return json_string.replace(/:\s*"([\s\S]*?)"(?=,\s*"[^"]+"\s*:|\s*\}|\s*\]|$)/g, (_match, value) => {
    const escaped_value = value.replace(/(?<!\\)"/g, '\\"');
    return `: "${escaped_value}"`;
  });
}

// ============================================================================
// [SECTION 3: PSEUDO-JSON & FIELD MERGING]
// ============================================================================

/**
 * High-fidelity parser that extracts pseudo-JSON configurations.
 * Exclusively parses bracketed `[KEY: VALUE]` parameters.
 * @param {string | null | undefined} raw - Raw input text.
 * @returns {Record<string, string | string[]>} Extracted key-value pairs.
 */
export const safe_parse_pseudo_json = (raw) => {
  if (!raw || typeof raw !== "string") return {};
  const clean_raw = strip_cognition_blocks(raw).trim();
  if (!clean_raw) return {};

  // Tier 1: Process bracketed configuration [KEY: VALUE] or [KEY: VALUE] [KEY2: VALUE2]
  if (clean_raw.includes("[") && clean_raw.includes("]")) {
    /** @type {Record<string, string | string[]>} */
    const bracket_extracted = {};
    const bracket_regex = /\[([^[\]]+)\]/g;
    let match;
    let matched_any = false;

    while ((match = bracket_regex.exec(clean_raw)) !== null) {
      for (const segment of _split_key_value_segments(match[1])) {
        matched_any = true;
        const k = segment.key.replace(/["']/g, "").trim().replace(/\s+/g, "_");
        const v = segment.value.replace(/^["']|["']$/g, "").trim();
        _store_parsed_entry(bracket_extracted, k, v);
      }
    }

    if (matched_any) return bracket_extracted;
  }

  // Tier 2: Process quoted key-value pairs "KEY": "VALUE" or JSON {"KEY": "VALUE"}
  if (clean_raw.includes('"') && clean_raw.includes(":")) {
    /** @type {Record<string, string | string[]>} */
    const quoted_extracted = {};
    const quoted_regex = /"([^"]+)"\s*:\s*"([^"]*)"/g;
    let match;
    while ((match = quoted_regex.exec(clean_raw)) !== null) {
      const k = match[1].trim().replace(/\s+/g, "_");
      const v = match[2].trim();
      if (k && v) quoted_extracted[k] = v;
    }
    if (Object.keys(quoted_extracted).length > 0) return quoted_extracted;
  }

  // Tier 2.5: Process unbracketed uppercase key-value pairs KEY: VALUE (e.g. "CLOTHING: tight tank top EXPRESSION: grin")
  if (clean_raw.includes(":")) {
    const unbracketed_regex = /\b([A-Z][A-Z0-9_]*(?:\s+[A-Z][A-Z0-9_]*)*)\s*:\s*([^:]+?)(?=\s+[A-Z][A-Z0-9_]*(?:\s+[A-Z][A-Z0-9_]*)*\s*:|$)/g;
    /** @type {Record<string, string | string[]>} */
    const unbracketed_extracted = {};
    let match;
    while ((match = unbracketed_regex.exec(clean_raw)) !== null) {
      const k = match[1].trim().replace(/\s+/g, "_");
      const v = match[2].trim();
      _store_parsed_entry(unbracketed_extracted, k, v);
    }
    if (Object.keys(unbracketed_extracted).length > 0) return unbracketed_extracted;
  }

  // Tier 3: No structured keys found — preserve raw prose sentinel.
  return { __raw_prose__: clean_raw };
};

/**
 * Safely parses the first JSON object or array contained within raw text/prose.
 * If prefix is supplied (e.g. from startWith), it evaluates raw with and without prefix.
 * Returns the parsed payload or null if no valid JSON is found.
 * @param {string | null | undefined} raw - Input string potentially containing JSON.
 * @param {object} [options={}]
 * @param {string} [options.prefix=""] - Optional prefill string (e.g. startWith) to reattach if model continued it.
 * @returns {any | null} Parsed object/array or null.
 */
export function safe_parse_json(raw, options = {}) {
  if (!raw || typeof raw !== "string") return null;

  const prefix = typeof options === "string" ? options : options?.prefix || "";
  const candidates = [raw];
  if (prefix) {
    candidates.push(prefix + raw);
  }

  for (const candidate of candidates) {
    const start = candidate.indexOf("{");
    const end = candidate.lastIndexOf("}");

    if (start !== -1 && end !== -1 && end > start) {
      try {
        return JSON.parse(candidate.slice(start, end + 1));
      } catch (_) {
        // Continue to array check or next candidate
      }
    }

    const arr_start = candidate.indexOf("[");
    const arr_end = candidate.lastIndexOf("]");
    if (arr_start !== -1 && arr_end !== -1 && arr_end > arr_start) {
      try {
        return JSON.parse(candidate.slice(arr_start, arr_end + 1));
      } catch (_) {
        // Continue to next candidate
      }
    }
  }

  return null;
}

/**
 * Pure simulation function that merges newly emitted [KEY: VALUE] bracket directives
 * into an entity's present physical/non-physical state field.
 * @param {string | null | undefined} current_field_value - Current field string.
 * @param {string | null | undefined} new_prose - Newly emitted mutations.
 * @returns {string} Reconciled state field string.
 */
export function merge_prose_into_field(current_field_value, new_prose) {
  if (!new_prose || !new_prose.trim()) return current_field_value || "";

  const MAX_FIELD_CHARS = 2000;
  const parsed = safe_parse_pseudo_json(current_field_value);
  const clean_new_prose = new_prose.trim();

  // Plain prose field (no structured keys, or raw-prose sentinel)
  if (!parsed || parsed.__raw_prose__ || Object.keys(parsed).length === 0) {
    const existing = (current_field_value || "").trim();
    if (!existing) return clean_new_prose;

    const normalize = (t) => collapse_whitespace(String(t || "").toLowerCase());
    const existing_lines = existing
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean);
    const existing_norm = new Set(existing_lines.map(normalize));

    const incoming_lines = clean_new_prose
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean);
    const retained_new = incoming_lines.filter((l) => !existing_norm.has(normalize(l)));

    if (retained_new.length === 0) {
      return existing;
    }

    let result = `${existing}\n${retained_new.join("\n")}`;
    if (result.length > MAX_FIELD_CHARS) {
      result = result.substring(result.length - MAX_FIELD_CHARS);
    }
    return result;
  }

  // 1. Extract bracketed [KEY: Value] directives first
  const bracketed_regex = /\[([A-Z_ ]{3,25}):\s*([\s\S]*?)\]/g;
  let match;
  const key_updates = [];

  while ((match = bracketed_regex.exec(clean_new_prose)) !== null) {
    const raw_key = match[1].toUpperCase().replace(/\s+/g, "_");
    const raw_val = match[2].trim();
    if (raw_val) {
      key_updates.push({ key: raw_key, val: raw_val });
    }
  }

  // Strip all bracketed directives cleanly in one pass to prevent string mutation drift
  let remaining_prose = clean_new_prose.replace(bracketed_regex, "").trim();

  // 2. Extract unbracketed KEY: Value segments if any
  const unbracketed_regex = /(?:^|,\s*|\s*)([A-Z_]{3,15}):\s*([^,[\]]+(?:\s+[^,[\]]+)*)/g;
  while ((match = unbracketed_regex.exec(remaining_prose)) !== null) {
    const raw_key = match[1].toUpperCase();
    const raw_val = match[2].trim();
    if (raw_val) {
      key_updates.push({ key: raw_key, val: raw_val });
    }
  }

  // Strip all unbracketed directives cleanly in one pass
  remaining_prose = remaining_prose
    .replace(unbracketed_regex, "")
    .replace(/^[\s,;[\]]+|[\s,;[\]]+$/g, "")
    .replace(/,\s*,+/g, ",")
    .trim();

  // Apply structured key updates in sequence
  for (const { key, val: incoming_val } of key_updates) {
    let target_key = key;
    let val = incoming_val;
    const is_clear_token = CLEAR_TOKENS.has(val.toLowerCase());

    // Wildcard purge: [CLOTHING: none] strips every clothing key at once.
    if (key === "CLOTHING" && is_clear_token) {
      for (const ck of CLOTHING_KEYS) delete parsed[ck];
      continue;
    }

    if (CLOTHING_KEYS.includes(key) && is_clear_token) {
      delete parsed[key];
      continue;
    }

    if (is_clear_token) {
      delete parsed[key];
      continue;
    }

    if (AGGREGATE_KEYS.has(key)) {
      const incoming = val
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
      const existing = parsed[key];
      const list = Array.isArray(existing)
        ? existing
        : existing
          ? String(existing)
              .split(",")
              .map((s) => s.trim())
              .filter(Boolean)
          : [];
      const existing_norm = new Set(list.map((item) => collapse_whitespace(String(item)).toLowerCase()));
      for (const item of incoming) {
        const item_norm = collapse_whitespace(item).toLowerCase();
        if (item && !existing_norm.has(item_norm)) {
          list.push(item);
          existing_norm.add(item_norm);
        }
      }
      parsed[key] = list;
      continue;
    }

    if (key === "CLOTHING" && parsed.SHIRT) target_key = "SHIRT";
    if (key === "SHIRT" && parsed.CLOTHING) target_key = "CLOTHING";

    // E2: Concealment preservation on structured key overwrite
    const existing_val = typeof parsed[target_key] === "string" ? parsed[target_key] : "";
    const existing_had_hide = /\|\s*hide\b/i.test(existing_val);
    const incoming_has_show = /\|\s*show\b/i.test(val);
    const incoming_has_hide = /\|\s*hide\b/i.test(val);
    if (existing_had_hide && !incoming_has_show && !incoming_has_hide) {
      val = `${val} | hide`;
    } else if (incoming_has_show) {
      val = val.replace(/\|\s*show\b/gi, "").trim();
    }

    parsed[target_key] = val;
  }

  // Append any remaining unstructured prose to CONDITION
  if (remaining_prose) {
    const cond_key = parsed.CONDITION ? "CONDITION" : parsed.condition ? "condition" : "CONDITION";
    if (parsed[cond_key]) {
      const clean_existing = String(parsed[cond_key])
        .replace(/^[\s,]+|[\s,]+$/g, "")
        .replace(/,\s*,+/g, ", ");
      const existing_phrases = clean_existing
        .split(",")
        .map((s) => collapse_whitespace(s).toLowerCase())
        .filter(Boolean);
      const incoming_phrases = remaining_prose
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
      const new_phrases = incoming_phrases.filter((phrase) => !existing_phrases.includes(collapse_whitespace(phrase).toLowerCase()));
      if (new_phrases.length > 0) {
        parsed[cond_key] = `${clean_existing}, ${new_phrases.join(", ")}`;
      }
    } else {
      parsed[cond_key] = remaining_prose;
    }
  }

  // Clean up double commas inside all values of parsed
  for (const k in parsed) {
    if (typeof parsed[k] === "string") {
      parsed[k] = parsed[k].replace(/^[\s,]+|[\s,]+$/g, "").replace(/,\s*,+/g, ", ");
    }
  }

  let lines = Object.entries(parsed)
    .map(([k, v]) => `[${k}: ${String(Array.isArray(v) ? v.join(", ") : v).replace(/[[]]/g, "")}]`)
    .join(" ");

  if (lines.length > MAX_FIELD_CHARS) {
    lines = lines.substring(lines.length - MAX_FIELD_CHARS);
  }

  return lines;
}

/**
 * Strips non-visual pseudo-JSON keys from a raw parameter string for image generation prompts.
 *
 * @param {string | null | undefined} raw_parameter_string
 * @returns {string} Sanitized visual parameter string
 */
export function strip_visual_excluded(raw_parameter_string) {
  if (!raw_parameter_string) return "";
  const parsed_parameters = safe_parse_pseudo_json(raw_parameter_string);
  if (parsed_parameters.__raw_prose__) return raw_parameter_string;

  const retained_entries = Object.entries(parsed_parameters)
    .filter(([key]) => !VISUAL_EXCLUDED_KEYS.has(key))
    .map(([key, value]) => `[${key}: ${Array.isArray(value) ? value.join(", ") : String(value).replace(/[[\]]/g, "")}]`);

  return retained_entries.join(" ");
}

// ============================================================================
// [SECTION 4: STRING FORMATTING & RELATIONAL VECTORS]
// ============================================================================

/**
 * Indents every line after the first (the caller supplies the leading-line
 * prefix) — the continuation-indent counterpart to `indent_all`.
 * @param {string | null | undefined} text
 * @param {number} spaces - Number of leading spaces to apply per continuation line.
 * @returns {string}
 */
export const indent_continuation = (text, spaces) => {
  if (!text) return "";
  const prefix = " ".repeat(spaces);
  return String(text).trim().split("\n").join(`\n${prefix}`);
};

/**
 * Derives up to 3 uppercase initials from a style or entity name.
 * @param {string | null | undefined} name - Style or entity display name.
 * @returns {string} Up to 3 uppercase initial letters.
 */
export function get_style_initials(name) {
  if (!name || name === "No Narrative Style" || name === "No Visual Style") return "?";
  return name
    .split(/[\s_-]+/)
    .map((w) => w.charAt(0))
    .join("")
    .slice(0, 3)
    .toUpperCase();
}

/**
 * Derives up to 3 uppercase initials from an entity name, skipping title/stop
 * prefixes (`NAME_PREFIX_STEMS`) when any remain. Falls back to the raw words
 * when every word is a stop word, and to "?" for empty input.
 * @param {string | null | undefined} text
 * @param {Set<string>} [stop_words=NAME_PREFIX_STEMS]
 * @returns {string}
 */
export function compute_initials(text, stop_words = NAME_PREFIX_STEMS) {
  const words = String(text || "")
    .replace(/[‘’']/g, "")
    .replace(/[^\p{L}\s]/gu, " ")
    .trim()
    .split(/\s+/);
  const filtered = words.filter((word) => !stop_words.has(word.toLowerCase()));
  return (
    (filtered.length ? filtered : words)
      .slice(0, 3)
      .map((word) => word.charAt(0))
      .join("")
      .toUpperCase() || "?"
  );
}

/**
 * Extracts a single short sentence (<= max_len chars) from a blob of text.
 * Strips think blocks, markdown fences, and excessive whitespace.
 * @param {string | null | undefined} text
 * @param {number} [max_len=160]
 * @returns {string}
 */
export function first_sentence(text, max_len = 160) {
  const clean = collapse_whitespace(strip_cognition_blocks(text).replace(/```/g, ""));
  if (!clean) return "";
  const regex = new RegExp(`^[^.!?]{1,${max_len}}[.!?:;]?`);
  const m = clean.match(regex);
  const sentence = (m ? m[0] : clean.slice(0, max_len)).trim();
  return sentence;
}

/**
 * Repairs unclosed or unopened brackets in state strings and directives.
 * Fixes malformed strings such as:
 * - "foo | w: 8]\n[BAR: baz" -> "[foo | w: 8]\n[BAR: baz]"
 * - "ANOMALY: alert" -> "[ANOMALY: alert]"
 *
 * @param {string | null | undefined} raw - Input string with potentially malformed brackets
 * @returns {string} Clean string where every bracket predicate is properly enclosed
 */
export function balance_brackets(raw) {
  if (!raw || typeof raw !== "string") return "";
  const lines = raw.split(/\r?\n/);
  const repaired_lines = lines.map((line) => {
    let trimmed = line.trim();
    if (!trimmed) return "";

    // Case 1: Line ends with ']' but does not start with '['
    if (trimmed.endsWith("]") && !trimmed.startsWith("[")) {
      trimmed = `[${trimmed}`;
    }

    // Case 2: Line starts with '[' but does not end with ']'
    if (trimmed.startsWith("[") && !trimmed.endsWith("]")) {
      trimmed = `${trimmed}]`;
    }

    // Case 3: Line has no brackets at all, but looks like a key-value or weight directive
    // e.g. "ANOMALY: alert | w: 8" or "@DR_TARIQ: hostile | hide"
    if (!trimmed.includes("[") && !trimmed.includes("]")) {
      const is_predicate = /^(@?[A-Z][A-Z0-9_]{1,24}:|[^:|]+\|\s*(?:w:\s*\d+|show|hide)\b)/.test(trimmed);
      if (is_predicate) {
        trimmed = `[${trimmed}]`;
      }
    }

    return trimmed;
  });

  return repaired_lines.join("\n").trim();
}

/**
 * Matches the capitalization of the original string on the replacement string.
 * If the first character of original is uppercase, capitalizes replacement.
 * @param {string | null | undefined} original
 * @param {string | null | undefined} replacement
 * @returns {string}
 */
export function match_case(original, replacement) {
  if (!original || !replacement) return replacement || "";
  const first_char = original.charAt(0);
  const is_uppercase = first_char === first_char.toUpperCase() && first_char !== first_char.toLowerCase();
  if (is_uppercase) {
    return replacement.charAt(0).toUpperCase() + replacement.slice(1);
  }
  return replacement;
}

/**
 * Auto-formats object keys into UI labels (e.g. "non_physical" -> "Non-Physical", "future" -> "Future").
 * @param {string | null | undefined} key
 * @returns {string}
 */
export function format_key_as_label(key) {
  if (!key || typeof key !== "string") return "";
  if (key === "non_physical") return "Non-Physical";
  return key
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

/**
 * Formats a timestamp as YYYY-MM-DD HH:mm (sv-SE locale, comma separator
 * stripped for a clean clock-style readout).
 * @param {number | string | Date | null | undefined} ts
 * @returns {string}
 */
export function format_datetime(ts) {
  if (!ts) return "---";
  return new Date(ts)
    .toLocaleString("sv-SE", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })
    .replace(",", "");
}

/**
 * Parses a directed relational vector string: `"[Source] → [Target]: [Dynamic]"`.
 * Tolerates various arrow notations (`→`, `->`, `—>`, `=>`, `—`).
 * @param {string | null | undefined} vector_str
 * @returns {ParsedRelationalVector | null}
 */
export function parse_relational_vector(vector_str) {
  if (!vector_str || typeof vector_str !== "string") return null;
  const raw = vector_str.trim();
  if (!raw) return null;

  // Match: Source → Target: Dynamic (or Source -> Target: Dynamic)
  const match = raw.match(/^([^\n→—=>:]+?)\s*(?:→|->|—>|=>|—)\s*([^\n:]+?)(?:\s*:\s*([\s\S]*))?$/);
  if (!match) return null;

  const source_name = (match[1] || "").trim();
  const target_name = (match[2] || "").trim();
  const dynamic = (match[3] || "").trim();

  if (!source_name || !target_name) return null;

  return {
    source_name,
    target_name,
    dynamic,
    raw,
  };
}

/**
 * Formats a canonical directed relational vector string.
 * @param {string} source_name
 * @param {string} target_name
 * @param {string} [dynamic=""]
 * @returns {string}
 */
export function format_relational_vector(source_name, target_name, dynamic = "") {
  const src = (source_name || "").trim();
  const tgt = (target_name || "").trim();
  const dyn = (dynamic || "").trim();
  if (!src || !tgt) return "";
  return dyn ? `${src} → ${tgt}: ${dyn}` : `${src} → ${tgt}`;
}

/**
 * Derives a punchy single-line header title from directive text.
 * @param {string | null | undefined} text - Raw directive text.
 * @param {number} [max_len=38] - Target maximum length.
 * @returns {string}
 */
export function derive_vector_title(text, max_len = 38) {
  if (!text || typeof text !== "string") return "";
  const cleaned = collapse_whitespace(text.replace(/^["'“”«»]+|["'“”«»]+$/g, ""));
  if (!cleaned) return "";
  return truncate_at_word(cleaned, max_len, { min_bound_chars: 15, strip_trailing_punctuation: true });
}

// ============================================================================
// [SECTION 5: HISTORY & STORY TITLE DECOMPOSITION]
// ============================================================================

/**
 * Maps an entry/message role to its human-readable display label used in
 * history envelopes (`User` / `Fractal` / `Character`). Single source for the
 * role→label ternary previously duplicated in history.js and transport.js.
 * @param {string | null | undefined} role
 * @returns {"User" | "Fractal" | "Character"}
 */
export function role_display_label(role) {
  const key = String(role || "").toLowerCase();
  if (key === "user" || key === "user_persona") return "User";
  if (key === "fractal") return "Fractal";
  return "Character";
}

/**
 * Resolves any raw role string to its canonical Sovereign RPGlitch role.
 *
 * @param {string|null|undefined} role
 * @returns {"user" | "ai" | "npc" | "fractal" | "system" | string}
 */
export function canonicalize_role(role) {
  const normalized = String(role || "")
    .toLowerCase()
    .trim();
  if (normalized === "user" || normalized === "user_persona") {
    return CANONICAL_ROLES.USER;
  }
  if (normalized === "ai" || normalized === "ai_character" || normalized === "model" || normalized === "assistant") {
    return CANONICAL_ROLES.AI;
  }
  if (normalized === "npc") {
    return CANONICAL_ROLES.NPC;
  }
  if (normalized === "fractal" || normalized === "prologue" || normalized === "epilogue" || normalized === "narrator") {
    return CANONICAL_ROLES.FRACTAL;
  }
  if (normalized === "system" || normalized === "telemetry") {
    return CANONICAL_ROLES.SYSTEM;
  }
  return role ? String(role).toLowerCase().trim() : CANONICAL_ROLES.AI;
}

/**
 * Canonical normalizer for turn beats, simulation log rows, and narrative dialog.
 * Unifies role mapping, cognition stripping, whitespace normalization, speaker
 * attribution, and image attachments into a clean, frozen record.
 *
 * @param {any} entry - Raw dialogue or log entry object.
 * @param {Object} [options={}]
 * @param {boolean} [options.include_cognition=false] - Whether to preserve <think> blocks.
 * @param {boolean} [options.normalize_whitespace=false] - Collapse multiple whitespace chars to single spaces.
 * @param {number} [options.max_chars] - Word-boundary character truncation limit.
 * @param {string} [options.text_source="content"] - "content" reads content ?? text; "text" reads text only.
 * @param {string} [options.label_policy="entry"] - "entry" resolves full origin chain; "visual" resolves Name: label.
 * @param {string} [options.label_fallback] - Fallback when attribution is unresolved.
 * @returns {Readonly<{
 *   role: string,
 *   raw_role: string,
 *   origin: string,
 *   character_name: string,
 *   text: string,
 *   attachments: ReadonlyArray<any>,
 *   round: number | null,
 *   timestamp: number | null,
 *   raw_entry: any
 * }>|null}
 */
export function normalize_history_beat(entry, options = {}) {
  if (!entry || typeof entry !== "object") return null;

  const {
    include_cognition = false,
    normalize_whitespace = false,
    max_chars,
    text_source = "content",
    label_policy = "entry",
    label_fallback,
  } = options;

  const raw_role = String(entry.role || "");
  const canonical_role = canonicalize_role(raw_role);

  const raw_text = text_source === "text" ? entry?.text : (entry?.content ?? entry?.text);
  let text = String(raw_text ?? "");
  if (!include_cognition) {
    text = strip_cognition_blocks(text);
  }
  text = text.trim();
  if (normalize_whitespace) {
    text = collapse_whitespace(text);
  }
  if (max_chars && max_chars > 0) {
    text = truncate_at_word(text, max_chars);
  }

  const fallback =
    label_fallback ??
    (label_policy === "visual"
      ? "narrator"
      : canonical_role === CANONICAL_ROLES.USER
        ? "User"
        : canonical_role === CANONICAL_ROLES.FRACTAL
          ? "Fractal"
          : "Character");

  const origin =
    label_policy === "visual"
      ? entry?.character_name || entry?.role || fallback
      : entry?.entity_id || entry?.origin || entry?.character_name || entry?.name || (entry?.role ? role_display_label(entry.role) : "") || fallback;

  const character_name = String(
    entry?.character_name || (canonical_role === CANONICAL_ROLES.USER ? "You" : entry?.origin || entry?.name || (origin !== fallback ? origin : "")),
  ).trim();

  const attachments = Array.isArray(entry.attachments) ? Object.freeze([...entry.attachments]) : Object.freeze([]);
  const round = entry.round != null && Number.isFinite(Number(entry.round)) ? Number(entry.round) : null;
  const timestamp = entry.timestamp ?? entry.created_at ?? null;

  return Object.freeze({
    role: canonical_role,
    raw_role,
    origin: String(origin),
    character_name,
    text,
    attachments,
    round,
    timestamp,
    raw_entry: entry,
  });
}

/**
 * @param {string | null | undefined} role
 * @returns {boolean} Whether a role is a narrative participant.
 */
export function is_narrative_role(role) {
  if (role == null) return false;
  return String(role).toLowerCase() !== CANONICAL_ROLES.SYSTEM;
}

/**
 * Collapses conversation history into role-grouped entries.
 * Consecutive messages from the same character are merged into a single entry.
 * @param {Array<HistoryMessage>} messages
 * @param {{ separator?: string, stripBoldQuotes?: boolean }} [options={}]
 * @returns {Array<CollapsedHistoryEntry>}
 */
export function collapse_history(messages, options = {}) {
  const { separator = "\n", stripBoldQuotes = false } = options;
  if (!Array.isArray(messages) || messages.length === 0) return [];

  const collapsed = [];
  for (const m of messages) {
    if (m.role === "system") continue;
    const lower_role = (m.role || "").toLowerCase();
    const role = ["user", "user_persona"].includes(lower_role)
      ? "user_persona"
      : ["prologue", "fractal"].includes(lower_role)
        ? "fractal"
        : "ai_character";
    const name = m.character_name || "";
    let content = strip_cognition_blocks(m.content || m.text || "");
    if (stripBoldQuotes) {
      content = content.replace(/\*\*\s*"(.*?)"\s*\*\*/g, '"$1"');
    }
    if (!content) continue;

    const last = collapsed[collapsed.length - 1];
    const is_same_speaker = last && last.role === role && last.name === name && (last.origin || "") === (m.origin || "");
    if (is_same_speaker) {
      last.content += `${separator}${content}`;
    } else {
      collapsed.push({ role, name, content, origin: m.origin });
    }
  }
  return collapsed;
}

/**
 * Filters a sequence of dialogue messages or log records to retain only narrative turns.
 * Strips out system messages and optionally excludes consolidated rounds.
 *
 * @param {Array<any>} messages - Array of dialogue/log records.
 * @param {Object} [options={}]
 * @param {boolean} [options.exclude_consolidated=false] - Whether to exclude turns already consolidated into memories.
 * @returns {Array<any>} Filtered narrative message records.
 */
export function filter_narrative_messages(messages, options = {}) {
  if (!Array.isArray(messages) || messages.length === 0) return [];
  const { exclude_consolidated = false, keep_resolved_image_rows = false } = options;

  return messages.filter((message) => {
    if (!message || message.role === CANONICAL_ROLES.SYSTEM) return false;
    if (exclude_consolidated && message.meta?.consolidated) return false;
    const text = String(message.content ?? message.text ?? "").trim();
    if (!text && !message.meta?.is_prologue && !message.meta?.is_epilogue) {
      if (keep_resolved_image_rows && Array.isArray(message.attachments)) {
        const first_source = message.attachments[0]?.src;
        if (typeof first_source === "string" && first_source.trim()) return true;
      }
      return false;
    }
    return true;
  });
}

/**
 * Universal conversation history serializer.
 * Transforms an array of messages/entries into clean XML `<ENTRY>` sequences with origin attributes,
 * round counters, stripped cognition blocks, and optional word-boundary truncation.
 *
 * @param {Array<any>} messages - Array of dialogue/log entries.
 * @param {Object} [options={}]
 * @param {number} [options.limit] - Optional window limit of entries to include from the end.
 * @param {number} [options.offset=0] - Offset from the end of the history window.
 * @param {number} [options.max_chars] - Maximum characters per entry before word-boundary truncation.
 * @param {boolean} [options.collapse=true] - Whether to collapse consecutive turns from the same speaker.
 * @param {string} [options.separator="\n\n"] - Separator between merged paragraphs in collapsed turns.
 * @param {boolean} [options.stripBoldQuotes=false] - Whether to strip bold markdown quotes during collapsing.
 * @param {number} [options.indent=0] - Leading space indentation preceding each <ENTRY> tag.
 * @returns {string} XML formatted <ENTRY> sequence string.
 */
export function format_history_entries(messages, options = {}) {
  if (!messages) return "";
  if (typeof messages === "string") return messages;
  if (!Array.isArray(messages) || messages.length === 0) return "";

  const { limit, offset = 0, max_chars, collapse = true, separator = "\n\n", stripBoldQuotes = false, indent = 0 } = options;

  const raw_entries = collapse ? collapse_history(messages, { separator, stripBoldQuotes }) : messages;

  const total = raw_entries.length;
  const start_index = limit ? Math.max(0, total - (limit + offset)) : 0;
  const end_index = Math.max(0, total - offset);

  const prefix = indent > 0 ? " ".repeat(indent) : "";

  return raw_entries
    .slice(start_index, end_index)
    .map((entry, index) => {
      const raw_text = String(entry?.content ?? entry?.text ?? "");
      const clean_text = strip_cognition_blocks(raw_text).trim();
      if (!clean_text) return null;

      const origin = entry.origin || entry.character_name || entry.name || (entry.role ? role_display_label(entry.role) : "") || "Character";
      const round_number = start_index + index + 1;
      const content = max_chars ? truncate_at_word(clean_text, max_chars) : clean_text;

      return `${prefix}<ACTION round="${round_number}" origin="${escape_xml(origin)}">${prompt_escape(content)}</ACTION>`;
    })
    .filter(Boolean)
    .join("\n");
}

/**
 * Decomposes a flat story title into styled title parts matching active entities.
 * Highlights AI, User, and Fractal names with their signature colors.
 * @param {string | null | undefined} title
 * @param {{ ai?: any, user?: any, fractal?: any, get_color?: (e: any) => string }} [entities={}]
 * @returns {Array<StoryTitlePart>}
 */
export function decompose_story_title(title, entities = {}) {
  if (!title || typeof title !== "string") return [{ text: "" }];
  const clean = title.trim();
  if (!clean) return [{ text: "" }];

  const { ai, user, fractal, get_color = () => "" } = entities;
  const matches = [];

  if (ai?.name) {
    const idx = clean.indexOf(ai.name);
    if (idx !== -1) {
      matches.push({
        name: ai.name,
        color: get_color(ai),
        start: idx,
        end: idx + ai.name.length,
      });
    }
  }
  if (user?.name && (!ai?.name || user.name !== ai.name)) {
    const idx = clean.indexOf(user.name);
    if (idx !== -1) {
      matches.push({
        name: user.name,
        color: get_color(user),
        start: idx,
        end: idx + user.name.length,
      });
    }
  }
  if (fractal?.name) {
    const idx = clean.indexOf(fractal.name);
    if (idx !== -1) {
      matches.push({
        name: fractal.name,
        color: get_color(fractal),
        start: idx,
        end: idx + fractal.name.length,
      });
    }
  }

  if (matches.length === 0) {
    return [{ text: clean }];
  }

  matches.sort((a, b) => a.start - b.start);

  const parts = [];
  let cursor = 0;
  for (const m of matches) {
    if (m.start > cursor) {
      parts.push({ text: clean.slice(cursor, m.start) });
    }
    if (m.start >= cursor) {
      parts.push({ text: m.name, color: m.color });
      cursor = m.end;
    }
  }
  if (cursor < clean.length) {
    parts.push({ text: clean.slice(cursor) });
  }

  return parts;
}

/**
 * Normalizes spacing after commas (e.g. "a,b,c" -> "a, b, c").
 * @param {string} str
 * @returns {string}
 */
export const normalize_comma_spacing = (str) => str.replace(/,([^\s])/g, ", $1");

// ============================================================================
// [SECTION 6: ALTERNATION MACROS — SELECTABLE OPTIONS & DICE RESOLUTION]
// ============================================================================

/**
 * Matches Perchance alternation groups `{Option A|Option B}` — the "macro leak"
 * syntax. Group 1 is the pipe-separated body.
 * @type {RegExp}
 */
export const ALTERNATION_PATTERN = /\{([^{}]+(?:\|[^{}]+)+)\}/g;

/**
 * Extracts every alternation group from a string.
 * @param {string | null | undefined} text
 * @returns {{ raw: string, options: string[] }[]}
 */
export function extract_alternations(text) {
  if (typeof text !== "string" || !text) return [];
  return [...text.matchAll(ALTERNATION_PATTERN)]
    .map((m) => ({
      raw: m[0],
      options: m[1]
        .split("|")
        .map((s) => s.trim())
        .filter(Boolean),
    }))
    .filter((g) => g.options.length >= 2);
}

/**
 * Whether a string contains at least one resolvable alternation group.
 * @param {string | null | undefined} text
 * @returns {boolean}
 */
export function has_alternations(text) {
  return extract_alternations(text).length > 0;
}

/**
 * Resolves every alternation group in a string to exactly ONE option.
 * This is the code-side DICE ROLL used by the image pipeline: each group picks
 * a uniformly random option (injectable `random` for determinism), and every
 * pick is reported through the optional `onPick` callback so it can be logged.
 * @param {string | null | undefined} text
 * @param {{ random?: () => number, onPick?: (pick: { raw: string, options: string[], index: number, option: string }) => void }} [opts={}]
 * @returns {{ text: string, picks: { raw: string, options: string[], index: number, option: string }[] }}
 */
export function resolve_alternations(text, opts = {}) {
  if (typeof text !== "string") return { text: text ?? "", picks: [] };
  const { random = Math.random, onPick = null } = opts;
  const picks = [];
  const resolved = text.replace(ALTERNATION_PATTERN, (raw, body) => {
    const options = body
      .split("|")
      .map((s) => s.trim())
      .filter(Boolean);
    if (options.length < 2) return raw;
    const index = Math.min(options.length - 1, Math.floor(random() * options.length));
    const pick = { raw, options, index, option: options[index] };
    picks.push(pick);
    if (typeof onPick === "function") onPick(pick);
    return options[index];
  });
  return { text: resolved, picks };
}

/**
 * Detects which alternation option a resolved string committed to.
 * Used on the text path: the LLM reads the braced options in its input and
 * writes a resolved value into state — this diff identifies the pick so it can
 * be logged as `[ALT] FIELD → option N "..." (narrative)`.
 * @param {string | null | undefined} source - Braced source text (what the LLM saw).
 * @param {string | null | undefined} resolved - Committed value (what the LLM wrote back).
 * @returns {{ raw: string, options: string[], index: number, option: string }[]}
 */
export function diff_alternation_picks(source, resolved) {
  if (typeof resolved !== "string") return [];
  const picks = [];
  for (const g of extract_alternations(source)) {
    const chosen = g.options.find((o) => o && resolved.includes(o));
    if (chosen) picks.push({ raw: g.raw, options: g.options, index: g.options.indexOf(chosen), option: chosen });
  }
  return picks;
}

/**
 * Belt-and-suspenders strip: resolves any alternation group that leaked into a
 * generated OUTPUT back to a single option (deterministically the first), so
 * story prose never surfaces braces or pipes.
 * @param {string | null | undefined} text
 * @returns {string}
 */
export function strip_alternation_braces(text) {
  if (typeof text !== "string") return text;
  return text.replace(ALTERNATION_PATTERN, (_raw, body) => {
    const options = body
      .split("|")
      .map((s) => s.trim())
      .filter(Boolean);
    return options[0] || "";
  });
}

/**
 * Human-friendly field label for an alternation group: the enclosing
 * `[KEY: ...]` bracket (e.g. `[SHIRT: {red|black}]` → "SHIRT"), or "" if the
 * group is not inside a bracket.
 * @param {string | null | undefined} text
 * @param {string} raw - The exact alternation group (`{A|B}`) to locate.
 * @returns {string}
 */
export function alternation_field_label(text, raw) {
  if (typeof text !== "string") return "";
  const idx = text.indexOf(raw);
  if (idx < 0) return "";
  const before = text.slice(0, idx);
  const last_open = before.lastIndexOf("[");
  const last_close = before.lastIndexOf("]");
  if (last_open > last_close) {
    const key = before
      .slice(last_open + 1)
      .split(":")[0]
      .trim();
    if (key) return key.toUpperCase();
  }
  return "";
}

/**
 * Tests one pattern/key against a haystack. Pass precedence: /regex/ literals
 * first, * ? glob wildcards second, bare strings as case-insensitive
 * whole-word matches last.
 * @param {string} pattern
 * @param {string} haystack
 * @returns {Readonly<{ hit: boolean, pass: "regex"|"glob"|"word"|"none" }>}
 */
export function match_keyword_pattern(pattern, haystack) {
  const needle = String(pattern ?? "").trim();
  const text = String(haystack ?? "");
  if (!needle || !text) return Object.freeze({ hit: false, pass: "none" });
  if (needle.length > 2 && needle.startsWith("/") && needle.lastIndexOf("/") > 0) {
    const last_slash = needle.lastIndexOf("/");
    try {
      if (new RegExp(needle.slice(1, last_slash), needle.slice(last_slash + 1)).test(text)) {
        return Object.freeze({ hit: true, pass: "regex" });
      }
    } catch {
      /* invalid regex falls through to literal matching */
    }
    return Object.freeze({ hit: false, pass: "none" });
  }
  if (needle.includes("*") || needle.includes("?")) {
    const glob = needle
      .split("")
      .map((char) => (char === "*" ? ".*" : char === "?" ? "." : char.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")))
      .join("");
    try {
      if (new RegExp(glob, "i").test(text)) return Object.freeze({ hit: true, pass: "glob" });
    } catch {
      /* unreachable — escaped construction cannot throw */
    }
    return Object.freeze({ hit: false, pass: "none" });
  }
  const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  if (new RegExp(`(^|[^A-Za-z0-9])${escaped}([^A-Za-z0-9]|$)`, "i").test(text)) {
    return Object.freeze({ hit: true, pass: "word" });
  }
  return Object.freeze({ hit: false, pass: "none" });
}

/**
 * Checks whether an entity has a directed bracket bond ([@target: ...]) or key targeting
 * another entity's id or name (case-insensitively).
 *
 * @param {any} entity - The source entity
 * @param {any|string} target_identifier_or_entity - Target entity object or identifier string
 * @returns {boolean}
 */
export function has_bracket_bond(entity, target_identifier_or_entity) {
  if (!entity || !target_identifier_or_entity) return false;

  const target_ids = new Set();
  if (typeof target_identifier_or_entity === "object") {
    if (target_identifier_or_entity.id) target_ids.add(String(target_identifier_or_entity.id).trim().toLowerCase());
    if (target_identifier_or_entity.name) target_ids.add(String(target_identifier_or_entity.name).trim().toLowerCase());
  } else {
    target_ids.add(String(target_identifier_or_entity).trim().toLowerCase());
  }

  const layers = [
    entity?.eternal?.non_physical,
    entity?.present?.non_physical,
    entity?.eternal?.physical,
    entity?.present?.physical,
    ...(Array.isArray(entity?.past) ? entity.past.map((item) => (typeof item === "string" ? item : item?.text)) : []),
    typeof entity?.future === "string" ? entity.future : "",
  ];

  for (const text of layers) {
    if (typeof text !== "string" || text.indexOf("[") < 0) continue;
    const matches = text.matchAll(/\[@?([^\]:]+):/g);
    for (const match of matches) {
      const parsed_target = String(match[1] || "")
        .trim()
        .toLowerCase();
      if (target_ids.has(parsed_target)) {
        return true;
      }
    }
  }

  return false;
}

// ============================================================================
// [SECTION 14: LLM PROSE SANITIZATION & NORMALIZATION]
// ============================================================================

/**
 * Detects whether an LLM generation ended abruptly or truncated mid-sentence.
 * Strips `<think>` tags and checks if the terminal character is valid sentence-ending punctuation.
 * @param {string} text
 * @returns {boolean}
 */
export function looks_truncated(text) {
  if (!text || typeof text !== "string") return false;
  if (!text.trim()) return false;

  const stripped = strip_cognition_blocks(text);

  if (!stripped) return true; // Think-only response or empty narrative

  const last_char = stripped[stripped.length - 1];
  const quotes = `"'“”‘’`;

  if (quotes.includes(last_char)) {
    const preceding = stripped.slice(0, -1).trimEnd();
    const prev_last = preceding[preceding.length - 1] || "";
    return !/[.!?…"]/.test(prev_last);
  }

  return !/[.!?…]/.test(last_char);
}

/**
 * Normalizes an LLM raw output result (primitive string or plugin String object with `.text`/`.generatedText`) into plain text.
 * @param {any} raw
 * @returns {string}
 */
export function raw_to_text(raw) {
  if (typeof raw === "string") return raw.trim();
  if (raw && typeof raw === "object") {
    return String(raw.generatedText ?? raw.text ?? "").trim();
  }
  return String(raw ?? "").trim();
}

/**
 * Extracts the server stop reason from a raw Perchance plugin result if attached.
 * @param {any} raw
 * @returns {string}
 */
export function raw_stop_reason(raw) {
  if (raw && typeof raw === "object" && !(raw instanceof String)) return "";
  return raw && typeof raw === "object" && raw.stopReason ? String(raw.stopReason) : "";
}

/**
 * Strips code fences, stray outer quotes, and conversational filler prefixes from LLM output.
 * Preserves `<think>` blocks for DevMode telemetry and database persistence.
 * @param {string} text
 * @returns {string}
 */
export function sanitize_llm(text) {
  if (!text) return "";

  // 1. Strip conversational filler and code fences
  let out = text
    .replace(/^(here is|sure|certainly|i can help|enhanced text:|the enhanced text).*?:/i, "")
    .replace(/^\s*```.*?[\r\n]/gm, "")
    .replace(/```\s*$/gm, "")
    .trim();

  // 2. Outer-quote cleanup: strip leading unmatched quote without destroying trailing dialogue quotes
  if (out.length > 1) {
    const first = out[0];
    if ((first === '"' || first === "'") && out[out.length - 1] !== first) {
      out = out.slice(1).trim();
    }
  }

  return out;
}
